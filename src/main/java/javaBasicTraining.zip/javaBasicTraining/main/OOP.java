package javaBasicTraining.main;

public class OOP {
		  int x;
		  public static void main(String[] args) {
			  OOP myObj = new OOP();
		    myObj.x = 40;
		    System.out.println(myObj.x);
		  }
}
