package javaBasicTraining.main;

public class Day4_Student {
	public static void main(String[] args) {
//		Day4_Person personObj = new Day4_Person();
//		   // personObj.name = "John";  // error vì name là private attribute
//		   // System.out.println(personObj.name); // error 
//		    personObj.setName("John");
//		    System.out.println(personObj.getName()); 
		
		Day4_Person thongTinXeMay = new Day4_Person();
		thongTinXeMay.setTenXeMay ("Vision");
		thongTinXeMay.setLoaiXeMay("Xe may");
		thongTinXeMay.setVanTocMax (12245);
		
		System.out.println(thongTinXeMay.getXeMayinfo());
		
		  }
	}

